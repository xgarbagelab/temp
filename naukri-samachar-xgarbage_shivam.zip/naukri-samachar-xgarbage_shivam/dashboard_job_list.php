
<style>
    .pagination li a{
        color:white;
        /*background-color: #2196f3;*/
    }
    
</style>
<div class="col l12 m12 s12">
    <p class="btn-floating  amber tooltipped"  data-position="right" data-delay="50" data-tooltip="Job List" style="margin:1% 0 0 1%"> 
        <i class=" fa fa-list"></i>
    </p>
</div>
<!--<div class="container">-->
    <!--<div class="row">-->
        <div class="col l12 m12 s12">
            <!--<h2 class="white-text">JOB POSTED BY YOU</h2>--><br><br>
            <div class="col ll2 m12 s12 center" style="margin:-3% 0 0 0" id="modfiy_action_button">
                <button class="btn-floating tooltipped green white-text" data-position="top" data-delay="50" data-tooltip="EDIT">
                    <i class="fa fa-pencil-square-o"></i>
                </button>
                <button class="btn-floating tooltipped red white-text" data-position="top" data-delay="50" data-tooltip="DELETE">
                    <i class="fa fa-trash"></i>
                </button>
                <button class="btn-floating tooltipped pink white-text" data-position="top" data-delay="50" data-tooltip="ARCHIVE">
                    <i class="fa fa-archive"></i>
                </button>
                <br><br>
            </div>
            <div id="pages">
                <div class="page col l12 m12 s12">
                    <div class="col l3 m4 s3 card center job-post">
                        <p>
                            <input type="checkbox" name="checkbox_action" class="checkbox_action" id="indeterminate-checkbox1">
                            <label for="indeterminate-checkbox1">Modify</label>
                        </p>
                        <h5 class=" ">South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <p>
                            <input type="checkbox" name="checkbox_action" class="checkbox_action" id="indeterminate-checkbox2">
                            <label for="indeterminate-checkbox2">Modify</label>
                        </p>
                        <h5 class=" ">South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                </div>
                <div class="page">
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div> 
                </div>
                <div class="page">
                     <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>  
                </div>
                <div class="page">
                      <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                </div>
                
                <div class="page">
                      <div class="col l3 m4 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                      
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                    
                    <div class="col l3 m3 s3 card center job-post">
                        <h5 class=" "><br>South India Banks Jobs</h5>
                        <p>201 Vacancies-PO - PAN India</p>
                        <p>Age - Not more than 25 years as on 31.12.2016.</p> 
                        <p>Candidate should be born on or after 01.01.1992</p>
                        <p>and on or before 31.12.1996</p>
                        <p><a href="#" class="center">See Details</a></p>
                    </div>
                </div>
              </div>
              <ul class="pagination  black-text center" id="myPager"></ul>
        <!--</div>-->
    </div>
<!--</div>-->

    


