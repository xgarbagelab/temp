<div class="col l12 m12 s12" style="margin:1% 0 0 0%">
    <p class="btn-floating tooltipped green" data-position="right" data-delay="50" data-tooltip="User Account">
        <i class="fa fa-user"></i>
    </p>
</div>

<div class="col l4 m4 s4 card offset-l4">
    
    <div class="input-field col l12 m12 s12">
        <input type="text"  id="username" class="">
        <label for="username" class="black-text">Your Username</label>
    </div>
    
    
    <div class="input-field col l12 m12 s12">
        <input type="text"  id="password" class="">
        <label for="password" class="black-text">Your Password</label>
    </div>
    
    <div class="input-field col l12 m12 s12">
        <input type="text"  id="cpassword" class="">
        <label for="cpassword" class="black-text">Your Confirm Password</label>
    </div>
    
    <div class="input-field col l12 m12 s12">
         <div class="file-field input-field">
      <div class="btn white black-text">
        <span>Upload Photo</span>
        <input type="file">
      </div>
      <div class="">
        <input class="file-path validate" type="text">
      </div>
    </div>
    </div>
    <div class="col l12 m12 s12 center">
        <a class="btn red white-text "  id="submit">UPDATE<i class="material-icons right">send</i></a>
        <br><br>
    </div>
    
</div>