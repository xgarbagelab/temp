<?php 
//    session_start();
//   $_SESSION['user_session'];
//   
//   if(!isset($_SESSION['user_session'])){
//       header("location:DatabaseConnection/Logout.php");
//   }
   
?>

            
                <div class="col l12 m12 s12 white-text">
                    <!--<h4 class="white-text">Home</h4>-->
                     
                </div>
                
<!--                <div class="col l12 m12 s12  white-text center" >
                    <div class="col l3 m3 s3 card red white-text">
                        <h2 class="center">UPDATE  PROFILE</h2>
                    </div>
                    
                     <div class="col l3 m3 s3 card teal offset-l1">
                        <h2 class="center ">CHECK MESSAGES</h2>
                    </div>
                    
                    <div class="col l3 m4 s4 card indigo offset-l1">
                        <h2 class="center ">NO OF TASKS</h2>
                        
                    </div>
                    
                     <div class="col l3 m4 s4 card lime">
                        
                        <h1 class="center">100</h1>
                        <p class="center ">NO OF REGISTERED USERS</p>
                    </div>
                    
                     <div class="col l3 m4 s4 card yellow offset-l1">
                        <h1 class="center">100</h1>
                        <p class="center ">NO OF JOBS POSTED</p>
                    </div>
                    
                    <div class="col l3 m4 s4 card pink offset-l1">
                        <h1 class="center">100</h1>
                        <p class="center ">NO OF JOBS POSTED</p>
                    </div>
                    
                </div>-->
<div class="col l12 m12 s12 ">
    <p class="btn-floating  blue tooltipped"  data-position="right" data-delay="50" data-tooltip="Home" style="margin:1% 0 0 1%"> <i class=" fa fa-home"></i></p>
     <br> <br>  
    <div class="col l3 m3 s3 center">
        <h2 class="card blue white-text">NO OF JOB POSTED BY YOU</h2>
    </div>
    
    <div class="col l3 m3 s3 center">
        <h2 class="card orange white-text">LAST JOB POSTED BY YOU</h2>
    </div>
    <div style="visibility: hidden">
    <div class="col l3 m3 s3">
        <h2 class="card yellow white-text"><br>KP OPTION 3<br><br></h2>
    </div>
    
    <div class="col l3 m3 s3">
        <h2 class="card blue white-text"><br>KP OPTION 4<br><br></h2>
    </div>
    
     <div class="col l3 m3 s3">
        <h2 class="card green white-text"><br>KP OPTION 3<br><br></h2>
    </div>
    
    <div class="col l3 m3 s3">
        <h2 class="card blue white-text"><br>KP OPTION 4<br><br></h2>
    </div>
    
     <div class="col l3 m3 s3">
        <h2 class="card red white-text"><br>KP OPTION 3<br><br></h2>
    </div>
    
    <div class="col l3 m3 s3">
        <h2 class="card pink white-text"><br>KP OPTION 4<br><br></h2>
    </div>
    </div>
</div>
           
       
                 
   
  